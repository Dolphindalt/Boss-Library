# Boss-Library
Recreation of Epic Bosses/Mob Library.

Authors: Dolphindalt, Crehop and ThaH3lper.

Recreated with express permission from Crehop.
